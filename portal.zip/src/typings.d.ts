declare let gapi: any;
declare let google: any;
