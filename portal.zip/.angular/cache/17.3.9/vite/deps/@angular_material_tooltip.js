import {
  MAT_TOOLTIP_DEFAULT_OPTIONS,
  MAT_TOOLTIP_DEFAULT_OPTIONS_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER,
  MatTooltip,
  MatTooltipModule,
  SCROLL_THROTTLE_MS,
  TOOLTIP_PANEL_CLASS,
  TooltipComponent,
  getMatTooltipInvalidPositionError,
  matTooltipAnimations
} from "./chunk-6HUTUR6A.js";
import "./chunk-H72BQUOP.js";
import "./chunk-4RFWVXZH.js";
import "./chunk-7Z3TWEEX.js";
import "./chunk-VLINDW5S.js";
import "./chunk-GQRFE32U.js";
import "./chunk-JGBBQFOS.js";
import "./chunk-7DTHLVVY.js";
import "./chunk-EUALND64.js";
import "./chunk-GEELG5XN.js";
import "./chunk-664N5FMB.js";
import "./chunk-JND6LT5A.js";
import "./chunk-532FTKWE.js";
import "./chunk-YBO3JQB4.js";
export {
  MAT_TOOLTIP_DEFAULT_OPTIONS,
  MAT_TOOLTIP_DEFAULT_OPTIONS_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER,
  MatTooltip,
  MatTooltipModule,
  SCROLL_THROTTLE_MS,
  TOOLTIP_PANEL_CLASS,
  TooltipComponent,
  getMatTooltipInvalidPositionError,
  matTooltipAnimations
};
//# sourceMappingURL=@angular_material_tooltip.js.map
