import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
} from "./chunk-6G2GBFMD.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-WZGOEWH4.js";
import "./chunk-H72BQUOP.js";
import "./chunk-4RFWVXZH.js";
import "./chunk-IYTRRUXI.js";
import "./chunk-7Z3TWEEX.js";
import "./chunk-VLINDW5S.js";
import "./chunk-GQRFE32U.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-JGBBQFOS.js";
import "./chunk-7DTHLVVY.js";
import "./chunk-EUALND64.js";
import "./chunk-GEELG5XN.js";
import "./chunk-664N5FMB.js";
import "./chunk-JND6LT5A.js";
import "./chunk-532FTKWE.js";
import "./chunk-YBO3JQB4.js";
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
//# sourceMappingURL=@angular_material_select.js.map
